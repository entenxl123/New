package com.example.phuree.ptumboon;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class MyListView extends BaseAdapter {
    private static Activity activity;
    private static LayoutInflater inflater;
    ArrayList<Todolist> myTodoList;

    public MyListView(Activity activity, ArrayList<Todolist> myTodoList) {
        this.myTodoList = myTodoList;
        this.activity = activity;
        inflater = (LayoutInflater)activity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return myTodoList.size();
    }

    @Override
    public Todolist getItem(int position) {
        return myTodoList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return myTodoList.get(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = convertView;
        v = inflater.inflate(R.layout.my_list_layout,null);
        TextView textView = (TextView)v.findViewById(R.id.Text);
        TextView textView1 = (TextView)v.findViewById(R.id.textView4);
        ImageView img = (ImageView)v.findViewById(R.id.imageView2) ;
        Todolist todolist = myTodoList.get(position);
        textView.setText(todolist.getTodoText());
        textView1.setText(todolist.getCity());

        return v;
    }
}
