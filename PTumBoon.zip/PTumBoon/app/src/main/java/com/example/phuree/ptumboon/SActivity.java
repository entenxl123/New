package com.example.phuree.ptumboon;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class SActivity extends AppCompatActivity {
private String im;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_s);

        Todolist text = (Todolist) getIntent().getSerializableExtra("Key");
        ImageView img = (ImageView)findViewById(R.id.imageView);
        if(text.getId()==1) {
            img.setImageResource(R.drawable.pic1);
        }else if(text.getId()==2){
            img.setImageResource(R.drawable.pic2);
        }else if(text.getId()==3){
            img.setImageResource(R.drawable.pic3);
        }else if(text.getId()==4){
            img.setImageResource(R.drawable.pic4);
        }else if(text.getId()==5){
            img.setImageResource(R.drawable.pic5);
        }else if(text.getId()==6){
            img.setImageResource(R.drawable.pic6);
        }else if(text.getId()==7){
            img.setImageResource(R.drawable.pic7);
        }else if(text.getId()==8){
            img.setImageResource(R.drawable.pic8);
        }else if(text.getId()==9){
            img.setImageResource(R.drawable.pic9);
        }else if(text.getId()==10){
            img.setImageResource(R.drawable.pic10);
        }else if(text.getId()==11){
            img.setImageResource(R.drawable.pic11);
        }else if(text.getId()==12){
            img.setImageResource(R.drawable.pic12);
        }else if(text.getId()==13){
            img.setImageResource(R.drawable.pic13);
        }else if(text.getId()==14){
            img.setImageResource(R.drawable.pic14);
        }else if(text.getId()==15){
            img.setImageResource(R.drawable.pic15);
        }else if(text.getId()==16){
            img.setImageResource(R.drawable.pic16);
        }else if(text.getId()==17){
            img.setImageResource(R.drawable.pic17);
        }else if(text.getId()==18){
            img.setImageResource(R.drawable.pic19);
        }else if(text.getId()==19){
            img.setImageResource(R.drawable.pic19);
        }else if(text.getId()==20){
            img.setImageResource(R.drawable.pic20);
        }else if(text.getId()==21) {
            img.setImageResource(R.drawable.pic21);
        }   else if(text.getId()==22) {
                img.setImageResource(R.drawable.pic22);
            }else if(text.getId()==23){
                img.setImageResource(R.drawable.pic23);
            }else if(text.getId()==24){
                img.setImageResource(R.drawable.pic24);
            }else if(text.getId()==25){
                img.setImageResource(R.drawable.pic25);
            }else if(text.getId()==26){
                img.setImageResource(R.drawable.pic26);
            }else if(text.getId()==27){
                img.setImageResource(R.drawable.pic27);
            }else if(text.getId()==28){
                img.setImageResource(R.drawable.pic28);
            }else if(text.getId()==29){
                img.setImageResource(R.drawable.pic29);
            }else if(text.getId()==30){
                img.setImageResource(R.drawable.pic30);
            }   else if(text.getId()==31) {
            img.setImageResource(R.drawable.pic31);
        }else if(text.getId()==32){
            img.setImageResource(R.drawable.pic32);
        }else if(text.getId()==33){
            img.setImageResource(R.drawable.pic33);
        }else if(text.getId()==34){
            img.setImageResource(R.drawable.pic34);
        }else if(text.getId()==35){
            img.setImageResource(R.drawable.pic35);
        }else if(text.getId()==36){
            img.setImageResource(R.drawable.pic36);
        }else if(text.getId()==37){
            img.setImageResource(R.drawable.pic37);
        }else if(text.getId()==38){
            img.setImageResource(R.drawable.pic38);
        }else if(text.getId()==39){
            img.setImageResource(R.drawable.pic39);
        }else if(text.getId()==40){
            img.setImageResource(R.drawable.pic40);
        }else if(text.getId()==41) {
            img.setImageResource(R.drawable.pic41);
        }else if(text.getId()==42){
            img.setImageResource(R.drawable.pic42);
        }else if(text.getId()==43){
            img.setImageResource(R.drawable.pic43);
        }else if(text.getId()==44){
            img.setImageResource(R.drawable.pic44);
        }else if(text.getId()==45){
            img.setImageResource(R.drawable.pic45);
        }else if(text.getId()==46){
            img.setImageResource(R.drawable.pic46);
        }else if(text.getId()==47){
            img.setImageResource(R.drawable.pic47);
        }else if(text.getId()==48){
            img.setImageResource(R.drawable.pic48);
        }else if(text.getId()==49){
            img.setImageResource(R.drawable.pic49);
        }else if(text.getId()==50){
            img.setImageResource(R.drawable.pic50);
        }else if(text.getId()==51) {
            img.setImageResource(R.drawable.pic51);
        }else if(text.getId()==52){
            img.setImageResource(R.drawable.pic52);
        }else if(text.getId()==53){
            img.setImageResource(R.drawable.pic53);
        }else if(text.getId()==54){
            img.setImageResource(R.drawable.pic54);
        }else if(text.getId()==55){
            img.setImageResource(R.drawable.pic55);
        }else if(text.getId()==56){
            img.setImageResource(R.drawable.pic56);
        }
        TextView textView = (TextView)findViewById(R.id.Show);
        textView.setText(text.getTodoText());
        TextView textView1 = (TextView)findViewById(R.id.textView2);
        textView1.setText(text.getBBB());
    }
}
