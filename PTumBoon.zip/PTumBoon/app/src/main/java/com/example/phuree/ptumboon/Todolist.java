package com.example.phuree.ptumboon;

import java.io.Serializable;

public class Todolist implements Serializable {
    private int id;
    private String todoText;
    private String city;
    private String BBB;
    private int Pri;
    private float la;
    private float longi;
    private int image;

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public float getLa() {
        return la;
    }

    public void setLa(float la) {
        this.la = la;
    }

    public float getLongi() {
        return longi;
    }

    public void setLongi(float longi) {
        this.longi = longi;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public int getPri() {
        return Pri;
    }

    public void setPri(int pri) {
        Pri = pri;
    }

    public String getBBB() {
        return BBB;
    }

    public void setBBB(String BBB) {
        this.BBB = BBB;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTodoText() {
        return todoText;
    }

    public void setTodoText(String todoText) {
        this.todoText = todoText;
    }
}
