package com.example.phuree.ptumboon;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class TodoListDAO {
    private SQLiteDatabase database;
    private DBHelper dbHelper;

    public TodoListDAO(Context context) {
        dbHelper = new DBHelper(context);
    }
    public void open() {
        database = dbHelper.getWritableDatabase();
    }
    public void close(){
        dbHelper.close();
    }

    public ArrayList<Todolist> getAll(){
        ArrayList<Todolist> todoList = new ArrayList<>();
        Cursor cursor = database.rawQuery("SELECT * FROM TODO;",null);
        cursor.moveToFirst();
        Todolist todolist1;
        while(!cursor.isAfterLast()){
            todolist1 = new Todolist();
            todolist1.setId(cursor.getInt(0));
            todolist1.setTodoText(cursor.getString(1));
            todolist1.setCity(cursor.getString(2));
            todolist1.setBBB(cursor.getString(3));
            todolist1.setPri(cursor.getInt(4));
            todolist1.setLa(cursor.getInt(5));
            todolist1.setLongi(cursor.getInt(6));
            todoList.add(todolist1);
            cursor.moveToNext();
        }
        cursor.close();
        return todoList;

    }
    public ArrayList<Todolist> getPri(){
        ArrayList<Todolist> todoList = new ArrayList<>();
        Cursor cursor = database.rawQuery("SELECT * FROM TODO Where Pri = 1;",null);
        cursor.moveToFirst();
        Todolist todolist1;
        while(!cursor.isAfterLast()){
            todolist1 = new Todolist();
            todolist1.setId(cursor.getInt(0));
            todolist1.setTodoText(cursor.getString(1));
            todolist1.setCity(cursor.getString(2));
            todolist1.setBBB(cursor.getString(3));
            todolist1.setPri(cursor.getInt(4));
            todolist1.setLa(cursor.getInt(5));
            todolist1.setLongi(cursor.getInt(6));
            todoList.add(todolist1);
            cursor.moveToNext();
        }
        cursor.close();
        return todoList;

    }
    public ArrayList<Todolist> getsome(Todolist s){
        ArrayList<Todolist> todoList = new ArrayList<>();
        Cursor cursor = database.rawQuery("SELECT * FROM TODO Where city =" +s+"%;",null);
        cursor.moveToFirst();
        Todolist todolist1;
        while(!cursor.isAfterLast()){
            todolist1 = new Todolist();
            todolist1.setId(cursor.getInt(0));
            todolist1.setTodoText(cursor.getString(1));
            todolist1.setCity(cursor.getString(2));
            todolist1.setBBB(cursor.getString(3));
            todolist1.setPri(cursor.getInt(4));
            todolist1.setLa(cursor.getInt(5));
            todolist1.setLongi(cursor.getInt(6));
            todoList.add(todolist1);
            cursor.moveToNext();
        }
        cursor.close();
        return todoList;

    }
}
