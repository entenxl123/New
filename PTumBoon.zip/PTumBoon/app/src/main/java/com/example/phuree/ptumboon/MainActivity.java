package com.example.phuree.ptumboon;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void doall(View v){
        Intent itn = new Intent(this,allActivity.class);
        startActivity(itn);
    }
    public void doPri(View v){
        Intent itn = new Intent(this,PriActivity.class);
        startActivity(itn);
    }
    public void doMap(View v){
        Toast.makeText(this,"wait Map",Toast.LENGTH_SHORT).show();

    }
}
