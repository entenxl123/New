package com.example.phuree.ptumboon;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class PriActivity extends AppCompatActivity {
    ListView todoListView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pri);

        todoListView = (ListView)findViewById(R.id.ListView1);

        TodoListDAO todoListDAO =  new TodoListDAO(getApplicationContext());
        todoListDAO.open();;
        ArrayList<Todolist> mylist = todoListDAO.getPri();

        //ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,mylist);
        final MyListView adapter = new MyListView(this,mylist);
        todoListView.setAdapter(adapter);
        todoListDAO.close();

        todoListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getApplicationContext(),String.valueOf(adapter.getItemId(position)),Toast.LENGTH_SHORT).show();
                Intent itn = new Intent(getApplicationContext(),SActivity.class);
                itn.putExtra("Key",adapter.getItem(position));
                startActivity(itn);
            }
        });
    }
}
