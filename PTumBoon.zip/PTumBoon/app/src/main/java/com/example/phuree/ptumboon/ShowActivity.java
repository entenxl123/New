package com.example.phuree.ptumboon;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

public class ShowActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show);

        Todolist text = (Todolist) getIntent().getSerializableExtra("Key");

        TextView textView = (TextView)findViewById(R.id.Show);
        textView.setText(text.getTodoText());
        TextView textView1 = (TextView)findViewById(R.id.textView2);
        textView1.setText(text.getBBB());
    }
}
